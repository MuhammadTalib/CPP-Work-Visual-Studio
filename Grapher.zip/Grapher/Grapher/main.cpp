#include<iostream>
using namespace std;
#include<stdlib.h>
#include<string>
#include <fstream>
#include"Graphics.h"
#include"Point.h"
#include"Point_Array.h"
#include"StraightLine.h"
#include"Line_Array.h"
#include"Shape_Array.h"
#include"Grapher.h"
int main(int argc, char **argv)
{
	system("color 3a");
	glutInit(&argc, argv);
	Grapher G;

	
	cout << endl;
	system("pause");
	return 0;
}
